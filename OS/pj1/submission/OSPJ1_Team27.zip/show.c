#include <linux/kernel.h>
#include <linux/linkage.h>

asmlinkage int sys_show(void) {
	printk("kchang r05922092\nsunfanyun b04902045\n");
        return 0;
}

