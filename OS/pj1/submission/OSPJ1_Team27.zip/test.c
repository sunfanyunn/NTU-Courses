#include <sys/syscall.h>
#include <unistd.h>
#include <stdio.h>
int main() {
	// test hello, check from dmesg
	syscall(337);
	//test show, check from dmesg
	syscall(338);
	//test multiply
	printf("8*7 = %d\n", syscall(339, 8, 7));
	//test min
	printf("min(100, 1) = %d\n", syscall(340, 100, 1));
	//test CPU Utilization, check from dmesg
	syscall(341);
	return 0;
}
