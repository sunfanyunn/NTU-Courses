#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/delay.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/syscalls.h>
#include <linux/fcntl.h>
#include <asm/uaccess.h>

asmlinkage int sys_CPU_Utilization(void) {
  int a[4], b[4];

  int fd;
  char buf[1024];
  char *filename="/proc/stat";

  mm_segment_t old_fs = get_fs();
  set_fs(KERNEL_DS);

  fd = sys_open(filename, O_RDONLY, 0);
  sys_read(fd, buf, 1024);
  sscanf(buf, "%*s %d %d %d %d", a, a+1, a+2, a+3);
  sys_close(fd);

  msleep(1000);

  fd = sys_open(filename, O_RDONLY, 0);
  sys_read(fd, buf, 1024);
  sscanf(buf, "%*s %d %d %d %d", b, b+1, b+2, b+3);
  sys_close(fd);

  printk("%d\n", (b[0]+b[1]+b[2]-a[0]-a[1]-a[2])*100/(b[0]+b[1]+b[2]+b[3]-a[0]-a[1]-a[2]-a[3]));

  set_fs(old_fs);
  return 0;
}




