#include <linux/kernel.h>
#include <linux/linkage.h>

asmlinkage long sys_min(long a, long b) {
	long ret=(a<b)?a:b;
	return ret;
}
