Ubuntu 16.04
flags are set to work on Windows
